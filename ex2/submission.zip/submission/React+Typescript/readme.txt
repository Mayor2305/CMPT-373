link: https://www.youtube.com/watch?v=ydkQlJhodio&t=208s

this tutorial didnt have any code implementation but it helped me understand how/why to use typescript and react together.