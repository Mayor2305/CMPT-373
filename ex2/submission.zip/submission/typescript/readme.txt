link: https://www.youtube.com/watch?v=ahCwqrYpIuM&t=609

this tutorial was about basics of typescript and how it is different from the JavaScript