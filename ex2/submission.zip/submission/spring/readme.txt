link: youtube.com/watch?v=YDRNMAJo0MA&t=290s

this tutorial helped me to learn about intellij and basics of spring boot