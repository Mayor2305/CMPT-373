link: https://www.youtube.com/watch?v=gAkwW2tuIqE&t=1s

this tutorial helped me to learn basics of docker and how to create and run an image