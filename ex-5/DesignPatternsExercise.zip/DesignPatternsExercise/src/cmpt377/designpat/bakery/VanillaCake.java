package cmpt377.designpat.bakery;

public class VanillaCake extends Cake {
    @Override
    public String getDescription() {
        return "Vanilla cake";
    }
}
