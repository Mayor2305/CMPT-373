package cmpt377.designpat.bakery;

public class ChocolateCake extends Cake {
    @Override
    public String getDescription() {
        return "Chocolate cake";
    }
}
