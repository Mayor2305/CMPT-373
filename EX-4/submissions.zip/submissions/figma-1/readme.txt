link: https://www.youtube.com/watch?v=jk1T0CdLxwU

this tutorial helped me to learn basics of figma and how to create a figme project
