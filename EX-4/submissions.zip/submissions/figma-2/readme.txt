link: https://www.youtube.com/watch?v=k74IrUNaJVk

this tutorial was about basics of figma and how its components are structured.
